import java.nio.file.Files;
import java.nio.file.Paths;

import com.google.crypto.tink.CleartextKeysetHandle;
import com.google.crypto.tink.JsonKeysetReader;
import com.google.crypto.tink.KeysetHandle;
import com.google.crypto.tink.Mac;
import com.google.crypto.tink.mac.MacConfig;

/**
 * Computes an authentication tag for the contents of a given file,
 * using the given key.
 */
public class ComputeTag {
  public static void main(String[] args) throws Exception {
    if (args.length != 3) {
      System.err.println("Usage: java ComputeTag <keyfile> <datafile> <tagfile>");
      System.exit(1);
    }

    // Configure Tink to use MAC primitives

    MacConfig.register();

    // Load key details from file specified on command line

    // Read data to be tagged from file specified on command line

    // Compute tag for the data

    // Write tag to file specified on command line

  }
}
